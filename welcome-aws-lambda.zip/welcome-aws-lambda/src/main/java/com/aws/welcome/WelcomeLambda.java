package com.aws.welcome;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

// AWS Lambda expressions need to implement specific interface
// RequestHandler<INPUT, OUTPUT>
public class WelcomeLambda implements RequestHandler<Object, String> 
{

	public String handleRequest(Object input, Context context) {
		System.out.println( "Hello Lambda!" );
		
		return "Hello Lambda!!!";
	}
}
