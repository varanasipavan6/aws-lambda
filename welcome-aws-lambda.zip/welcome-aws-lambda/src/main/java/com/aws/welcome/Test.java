package com.aws.welcome;

public class Test {

//	private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();

	// clean package shade:shade
	public static void main(String[] args) {
		Test app = new Test();
		app.go();

	}

	private void go() {
		WelcomeLambda restore = new WelcomeLambda();
		restore.handleRequest(null, null);
	}

}
